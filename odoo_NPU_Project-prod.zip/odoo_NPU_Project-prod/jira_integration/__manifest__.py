{
    'name': 'Solvve Jira Integration',

    'version': '18.0.0.0.1',
    'author': 'Oleh Oshchypok Solvve',
    'website': 'https://solvve.com/',
    'license': 'OPL-1',
    'category': 'Resources/Recruitment/Integration',

    'depends': ['documents', 'documents_spreadsheet', 'project', 'npu_fields_customize', 'queue_job'],

    'data': [
        'views/queue_job_views.xml',
        'data/queue_job_data.xml',
        'security/security.xml',
        'security/ir.model.access.csv',
        'views/project_project.xml',
        'views/jira_integration_settings.xml',
        'views/ir_menu.xml',
    ],
    'installable': True,
    'assets': {
        'web.assets_backend': [
            'npu_fields_customize/static/src/components/**/*',
        ],
    }
}
