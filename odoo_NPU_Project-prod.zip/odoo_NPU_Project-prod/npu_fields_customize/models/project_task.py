from odoo import api, fields, models


class Task(models.Model):
    _inherit = "project.task"

    task_number = fields.Char(string="Task Number")
    issue_type = fields.Char(string="Issue Type")
    link_to_jira_task = fields.Char(string="Link to Jira Task")
    counterparty = fields.Many2one("res.partner", string="Counter Party")
