/** @odoo-module **/

import { registry } from "@web/core/registry";
import { CharField, charField } from "@web/views/fields/char/char_field";

// Ensure that in Hoot tests, this module is loaded after `@mail/js/onchange_on_keydown`
// (needed because that module patches `charField`).
import "@mail/js/onchange_on_keydown";

export class CharWithLinkField extends CharField {
    static template = "npu_fields_customize.CharWithLinkField";

}

export const charWithLinkField = {
    ...charField,
    component: CharWithLinkField,
};

registry.category("fields").add("char_with_link_field", charWithLinkField);
