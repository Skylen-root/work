NPU Project fields customize
==============================

