# -*- coding: UTF-8 -*-
# Copyright 2024 Solvve, Inc. <sales@solvve.com>
{
    'name': 'List many2many_tags Overflow',
    'version': '18.0.0.0.1',
    'author': "Solvve, Inc.",
    'license': 'OPL-1',
    'website': 'https://solvve.com',
    'depends': ['web'],
    'assets': {
        'web.assets_backend': [
            'list_many2many_tags_field_overflow/static/src/js/*.js',
            'list_many2many_tags_field_overflow/static/src/scss/*.scss',
            'list_many2many_tags_field_overflow/static/src/xml/*.xml',
        ],
    },
}
