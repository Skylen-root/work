/** @odoo-module **/

import {Component} from '@odoo/owl';

export class Many2ManyTagsCollapseButton extends Component {
    static template = 'list_many2many_tags_field_overflow.CollapseButton';
    static props = {
        tags: {type: Array, optional: true},
        onClick: {type: Function},
        collapsed: {type: Boolean, optional: true},
    };
    static defaultProps = {
        tags: [],
        collapsed: true,
    };

    /**
     * @returns {String}
     */
    get iconClass() {
        return this.props.collapsed ? 'fa-chevron-down' : 'fa-chevron-up';
    }
}
