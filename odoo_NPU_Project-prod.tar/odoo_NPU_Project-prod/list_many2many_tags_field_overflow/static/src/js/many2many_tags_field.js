/** @odoo-module **/

import {patch} from '@web/core/utils/patch';
import {
    Many2ManyTagsField, many2ManyTagsFieldColorEditable, Many2ManyTagsFieldColorEditable,
} from '@web/views/fields/many2many_tags/many2many_tags_field';
import {Many2ManyTagsCollapseButton} from '@list_many2many_tags_field_overflow/js/many2many_tags_collapse';
import {useState} from '@odoo/owl';
import { useService } from "@web/core/utils/hooks";
import { _t } from "@web/core/l10n/translation";

import { registry } from "@web/core/registry";

patch(Many2ManyTagsField, {
    components: {...Many2ManyTagsField.components, Many2ManyTagsCollapseButton},
    props: {...Many2ManyTagsField.props,
        //onClick: {type: Function, optional: true},
    },
});

/**
 * @property {Number} maxTagsNumber
 */
patch(Many2ManyTagsField.prototype, {
    setup() {
        //this._super.apply(this, arguments);
        super.setup(...arguments);
        this.maxTagsNumber = 2;
        this.collapsed = useState({value: this.displayCollapseButton});
        this.action = useService("action");
    },

    onClick(ev) {
       return super.onClick(ev)
    },

    get tags() {
        const {records} = this.props.record.data[this.props.name];
        if (records.length && this.collapsed.value) {
            return [this.getTagProps(records[0])];
        }
        return super.tags  //this._super.apply(this, arguments);
    },

    /**
     * @returns {Number}
     */
    get totalTagsNumber() {
        //return Object.keys(this.props.record.data).length
        return this.props.record.data[this.props.name].records.length;
    },

    /**
     * @returns {Boolean}
     */
    get displayCollapseButton() {
        return this.props.readonly && this.totalTagsNumber > this.maxTagsNumber;
    },

    _onCollapseChange() {
        this.collapsed.value = !this.collapsed.value;
    }
});

patch(Many2ManyTagsFieldColorEditable, {
    components: {...Many2ManyTagsFieldColorEditable.components, Many2ManyTagsCollapseButton},
    props: {...Many2ManyTagsFieldColorEditable.props,
        onClick: {type: Function},
    },
});

patch(Many2ManyTagsFieldColorEditable.prototype, {

    onTagClick(ev, record) {
        console.log(`Tag clicked ${record}`)
        return this.onBadgeClick(ev, record)
    },

    onBadgeClick(ev, record) {
        console.log(`Badge clicked ${record}`)
        this.action.doAction({
            type: 'ir.actions.act_window',
            res_model: record.model.config.resModel,  // ev.currentTarget.dataset.model,
            res_id: record.resId,  //Number(ev.currentTarget.dataset.resId),
            //name: _t('Share Appointment'),
            views: [[false, 'form']],
            view_mode: "list",
            target: 'current',
            context: {
                active_id: record.resId,
            },
        });
        return super.onTagClick(ev, record)
    },

});

registry.category("fields").add("many2many_tags_views", many2ManyTagsFieldColorEditable);
