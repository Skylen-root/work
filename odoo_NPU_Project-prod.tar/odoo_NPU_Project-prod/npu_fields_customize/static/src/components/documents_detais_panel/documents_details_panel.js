import { patch } from '@web/core/utils/patch';
import { DocumentsDetailsPanel } from "@documents/components/documents_details_panel/documents_details_panel";
import { DateTimeField } from '@web/views/fields/datetime/datetime_field';
import { CharWithLinkField } from '@npu_fields_customize/components/char_with_link_field/char_with_link_field';


patch(DocumentsDetailsPanel, {
    components: {
        ...DocumentsDetailsPanel.components,
        DateTimeField,
        CharWithLinkField,
    },
});
