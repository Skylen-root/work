# -*- coding: utf-8 -*-

import logging

import odoo
from odoo import _, api, Command, fields, models


_logger = logging.getLogger(__name__)


class Document(models.Model):
    _inherit = 'documents.document'

    display_name = fields.Char(string='Display Name', compute='_compute_display_name', store=True)
    agreement_number = fields.Char(string="Agreement Number", tracking=True)
    agreement_effective_date = fields.Date(string="Agreement (effective) date", tracking=True)
    brand_id = fields.Many2one('res.partner.brand', string="Brand", tracking=True)
    counterparty = fields.Many2one('res.partner', string="Counter Party", tracking=True)
    type_of_subject = fields.Char(string="Type of agreement", tracking=True)
    type_of_partner = fields.Char(string="Type of partner", tracking=True)
    agreement_amount = fields.Char(string="Agreement amount", tracking=True)
    expiration_date = fields.Date(string="Expiration Date", tracking=True)
    parent_document_id = fields.Many2one('documents.document', string="Parent Document", tracking=True, domain="[('type', '=', 'binary'), ('id', '!=', id)]")
    addition_agreements = fields.One2many('documents.document', 'parent_document_id', tracking=True, domain="[('type', '=', 'binary'), ('id', '!=', id)]")
    document_link = fields.Char(string="Document Link", tracking=True)
    jira_task_link = fields.Char(string="Jira Task Link", tracking=True)
    notes = fields.Char(string="Notes", tracking=True)
    odoo_task = fields.Many2one('project.task', string="Odoo Task", tracking=True)
    auto_renewal = fields.Char(string="Auto Renewal", tracking=True)
    agreement_link = fields.Char(string="Agreement link", tracking=True)
    status = fields.Char(string="Status", tracking=True)
    termination_date = fields.Date(string="Termination date (if applicable)", tracking=True)
    termination_agreement_link = fields.Char(string="Termination agreement link", tracking=True)

    alias_addition_agreements_ids = fields.Many2many('documents.document',
                                                     'document_alias_addition_agreements_rel',
                                                     string="Addition Agreements",
                                                     compute='_compute_addition_agreements_ids',
                                                     inverse='_compute_inverse_addition_agreements_ids', domain="[('type', '=', 'binary'), ('id', '!=', id)]")

    @api.depends('parent_document_id')
    def _compute_parent_document_id(self):
        # todo: below 2 methods need to bee modified and activated in future or use alias_addition_agreements_ids instead addition_agreements
        # for allow edit by adding and removing badges from widget many2many, now working only when parent document modified
        # known issues: 1 changes doesn't visible before screen did not refreshed or rendered between switching tabs
        # changes on many2many widget do not saved
        # before only test code
        for rec in self:
            if rec.parent_document_id:
                rec.parent_document_id.write({'addition_agreements': (4, rec.id)})
                rec.parent_document_id.alias_addition_agreements_ids = rec.parent_document_id.addition_agreements
            else:
                recs = self.search([('addition_agreements', 'in', [rec.id])])
                for doc in recs:
                    doc.write({'addition_agreements': (3, rec.id)})
                    doc.alias_addition_agreements_ids = doc.addition_agreements

    @api.depends('addition_agreements', 'alias_addition_agreements_ids')
    def _compute_inverse_addition_agreements_ids(self):
        for rec in self:
            rec.addition_agreements = rec.alias_addition_agreements_ids
            for doc in rec.addition_agreements:
                doc.parent_document_id = rec

    @api.depends('addition_agreements', 'alias_addition_agreements_ids')
    def _compute_addition_agreements_ids(self):
        for rec in self:
            rec.alias_addition_agreements_ids = rec.addition_agreements

    def _compute_display_name(self):
        for rec in self:
            rec.display_name = rec.name
