# -*- coding: utf-8 -*-

import logging

import odoo
from odoo import _, api, Command, fields, models


_logger = logging.getLogger(__name__)


class Document(models.Model):
    _inherit = 'documents.document'

    agreement_number = fields.Char(string="Agreement Number", tracking=True)
    agreement_effective_date = fields.Date(string="Agreement (effective) date", tracking=True)
    brand_id = fields.Many2one('res.partner.brand', string="Brand", tracking=True)
    counterparty = fields.Many2one('res.partner', string="Counter Party", tracking=True)
    type_of_subject = fields.Char(string="Type of agreement", tracking=True)
    type_of_partner = fields.Char(string="Type of partner", tracking=True)
    agreement_amount = fields.Char(string="Agreement amount", tracking=True)
    expiration_date = fields.Date(string="Expiration Date", tracking=True)
    parent_document_id = fields.Many2one('documents.document', string="Parent Document", tracking=True)
    addition_agreements = fields.One2many('documents.document', 'parent_document_id', tracking=True)
    document_link = fields.Char(string="Document Link", tracking=True)
    jira_task_link = fields.Char(string="Jira Task Link", tracking=True)
    notes = fields.Char(string="Notes", tracking=True)
    odoo_task = fields.Many2one('project.task', string="Odoo Task", tracking=True)
    auto_renewal = fields.Char(string="Auto Renewal", tracking=True)
    agreement_link = fields.Char(string="Agreement link", tracking=True)
    status = fields.Char(string="Status", tracking=True)
    termination_date = fields.Date(string="Termination date (if applicable)", tracking=True)
    termination_agreement_link = fields.Char(string="Termination agreement link", tracking=True)
