from odoo import _, api, Command, fields, models

class Document(models.Model):
    _name = 'res.partner.brand'
    _description = 'Brand Name aka Trademark'

    name = fields.Char(string="Brand Name")
