{
    'name': 'NPU Project fields customize',

    'version': '18.0.0.0.1',
    'author': 'Oleh Oshchypok Solvve',
    'website': 'https://solvve.com/',
    'license': 'OPL-1',
    'category': 'Accounting',

    'depends': ['documents', 'documents_spreadsheet', 'project'],

    'data': [
        'views/project_task_views.xml',
        'views/documents_views.xml',
        'security/ir.model.access.csv',
    ],
    'installable': True,
    'assets': {
        'web.assets_backend': [
            'npu_fields_customize/static/src/components/**/*',
        ],
    }
}
