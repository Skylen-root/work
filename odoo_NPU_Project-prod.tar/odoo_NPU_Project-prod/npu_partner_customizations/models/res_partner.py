from odoo import models, fields

class ResPartner(models.Model):
    _inherit = 'res.partner'

    utilities_registration = fields.Char(string="Utilities Registration")
    date_of_registration = fields.Date(string="Date of Registration")
    license = fields.Char(string="License")
    main_business_activity = fields.Text(string="Main Business Activity")
    size_activity_number_inflows = fields.Char(string="Size of Activity - Inflows (number)")
    size_activity_eur_inflows = fields.Char(string="Size of Activity - Inflows (mln EUR)")
    size_activity_number_outflows = fields.Char(string="Size of Activity - Outflows (number)")
    size_activity_eur_outflows = fields.Char(string="Size of Activity - Outflows (mln EUR)")
