{
    'name': 'NPU Project fields customize',
    'version': '18.0.0.0.1',
    'author': 'solvve',
    'website': 'https://solvve.com/',
    'license': 'OPL-1',
    'category': 'Sales/CRM',
    'depends': ['base', 'contacts'],
    'data': [
        'views/res_partner.xml',
    ],
    'installable': True,
}
