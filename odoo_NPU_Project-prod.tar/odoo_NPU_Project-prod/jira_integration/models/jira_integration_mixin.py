# Copyright 2025 Solvve.com Oleh Oshchypok
# Jira Integration mixin

from odoo import models, fields, _, Command
from odoo.addons.sale_stock.models.res_company import company

from pydantic import BaseModel, Field
import logging
from typing import Any, Dict, Type, Optional, get_origin, get_args, List, Union
import objectpath
import json


class ObjectPath(str):

    def __init__(self, source):
        self.tree = objectpath.Tree(source)

    def execute(self, match):
        return self.tree.execute(match)

logger = logging.getLogger(__name__)

class RelatedModel:
    ...

class JsonPathObject:
    ...

class OdooMapModel(BaseModel):
    _model_name: str
    def __call__(self, odoo_model, source_data: dict, **kwargs) -> "OdooMapModel":
        if type(source_data) is not dict:
            source_data = json.loads(source_data)
        if self._model_name != odoo_model._name:
            raise ValueError(f'Error Mapping {self._model_name} != {odoo_model._name} for {self} OdooMapper')
        return self.populate_dataclass(odoo_model, source_data, **kwargs)

    def populate_dataclass(self, odoo_model, source_data: dict, **kwargs) -> Optional["OdooMapModel"]:
        orm_commands = []
        postprocess_commands = []
        orm_item = {}
        kwargs.setdefault('object_path', '')
        current_object_path = kwargs['object_path']
        tree = ObjectPath(source_data)
        for key, val in type(self).model_fields.items():
            value_path = val.alias or val.json_schema_extra.get('json_path')
            odoo_model = val.json_schema_extra and val.json_schema_extra.get('_model_name') and odoo_model.env[val.json_schema_extra.get('_model_name')] or odoo_model
            res_data = tree.execute(value_path)
            if res_data is None:
                logger.warning(f'Mapping Object for {odoo_model} {key} current path: {kwargs["object_path"]} object_path {val} not found')
            if val.default_factory == list:
                list_class = get_args(val.annotation)[0]
                if type(res_data) is list:
                    for data in res_data:
                        kwargs['object_path'] = f'{current_object_path}[{len(orm_commands)}]'
                        collect = list_class()(odoo_model, data, **kwargs)
                        if key == "records":
                            orm_commands.append(Command.create(collect))
                        else:
                            orm_commands.append({key: Command.create(collect)})
                else:
                    logger.warning(f'Mapping Object for {odoo_model} {key} current path: {kwargs["object_path"]} object_path {val} not correspond expected list type')
            elif get_origin(val.annotation) not in [dict, list]:
                if type(res_data) in [dict, list]:
                    logger.warning(f'Mapping Object for {odoo_model} {key} current path: {kwargs["object_path"]} object_path {val} not expected dict or list type it expect {get_origin(val.annotation)}')
                else:
                    if not res_data:
                        res_data = val.default or val.default_factory
                    orm_item[key] = res_data
                kwargs['object_path'] = f'{current_object_path}.{key}'
                if val.json_schema_extra and val.json_schema_extra.get('normalize'):
                    postprocess_commands.append((val.alias or val.json_schema_extra.get('normalize'), key, kwargs['object_path'], res_data))
            elif get_origin(val.annotation) == dict:
                obj_class = get_args(val.annotation)[0]
                collect = obj_class()(odoo_model, res_data, **kwargs)
                if type(res_data) is not dict:
                    logger.warning(f'Mapping Object for {odoo_model} {key} current path: {kwargs["object_path"]} object_path {val} not correspond expected dict type')
                else:
                    orm_item[key] = Command.create(collect)
                    kwargs['object_path'] = f'{current_object_path}.{key}'
        if postprocess_commands:
            for command, key, object_path, arg in orm_commands:
                orm_item[key] = command(odoo_model, arg)
        if orm_commands:
            return orm_commands
        odoo_fields = odoo_model.fields_get().keys()
        if orm_item:
            orm_item.setdefault('extra_fields', {})
            for field in orm_item.keys():
                if field not in odoo_fields:
                    orm_item['extra_fields'].update({field: orm_item[field]})
            for field in orm_item['extra_fields'].keys():
                del orm_item[field]
            return orm_item
        logger.warning(f'Mapping Object for {odoo_model} by mapping class {type(self)} is empty, check the odoo map class')


class OdooMapRecord(OdooMapModel):
    _model_name: str = 'model.model'
    uid: int = Field(
        json_schema_extra={
            '_model_name': 'res.users',
            'json_path': '$.user',  # object path in dict {"user": "Donald"}
            'domain': [],  # for fetch duplicate data in model on mapping stage if need, for now using postprocessing principes
            'normalize': lambda x: x,  # for import data casting for example date:mm/dd/yy->date:YYYY/MM.DD, cost:$12 = cost:12
            'reverse_json_path': None, # for export use benedict for generation
            'reverse_normalize': lambda x: x,  # for export data normalizer
        }
    )
    name: str = Field(alias='$.name')

class OdooMapModelList(OdooMapModel):
    _model_name: str = 'model.model'
    records: List[OdooMapRecord] = Field(  # records - reserved for top level or model objects
        default_factory=list,
        json_schema_extra={'json_path': '$[]'},
    )

class JiraIntegrationMixin(models.AbstractModel):
    _name = 'jira.integration.mixin'
    _description = 'Abstract Jira Integration model'
    #_rec_name = 'jira_name'
    _order = 'id desc'

    _res_model = ''
    _related_field = ''
    _odoo_map_list = OdooMapModelList
    _odoo_map_record = OdooMapRecord

    _http_method_import = 'GET'
    _http_method_export = 'POST'
    _api_endpoint = '/api/2/'

    _api_import_request_params = None  # {REMOTE_KEY} inside as parameter to

    _api_import_dependency = None  # use for retrieve {REMOTE_KEY} from odoo model where get jira_key or jira_id

    _api_export_request_params = None  # {REMOTE_KEY} inside as parameter to

    _api_export_dependency = None  # use for retrieve {REMOTE_KEY} from odoo model where get jira_key or jira_id

    jira_integration_settings = fields.Many2one('jira.integration.settings', 'Jira Instance')

    jira_id = fields.Text(
        string='Jira ID',
        company_dependent=True,
        copy=False,
        help='Remote Object ID, used for mapping local object'
    )

    jira_key = fields.Text(
        string='Jira Key',
        company_dependent=True,
        copy=False,
        help='Remote Object Key, used for mapping local object'
    )

    allow_sync = fields.Boolean(default=True, string='Allow synchronization')

    jira_sync_transaction_info = fields.Text(
        string='Transaction Info',
        company_dependent=True,
        copy=False,
    )
    jira_sync_transaction_date = fields.Datetime(
        string='Transaction Date',
        company_dependent=True,
        copy=False,
    )
    jira_sync_state = fields.Selection(
        selection=[
            ('todo', 'ToDo'),
            ('rejected', 'Rejected'),
            ('pending', 'Pending'),
            ('failed', 'Failed'),
            ('proxy', 'Done'),
        ],
        string='Sync Status',
        default='todo',
        company_dependent=True,
        copy=False,
    )

    extra_fields = fields.Json(string='Extra Fields')

    def _save_transaction_info(self, state, info, company_id):
        self.ensure_one()
        company = self.env['res.company'].browse(company_id)

        self.with_company(company).write({
            'jira_sync_state': state,
            'jira_sync_transaction_info': info.strip(),
            'jira_sync_transaction_date': fields.Datetime.now(),
        })

    def _get_job_params(self, **kwargs):
        #self.ensure_one()

        return dict(
            max_retries=1,
            priority=10,
            identity_key=f'jira_{kwargs.get("mode")}_{self}',
            description=f'Jira {kwargs.get("mode")} {self._description} "{self.display_name}"',
            channel=self.sudo().env.ref('jira_integration.channel_root_jira_1').complete_name,
        )

    def _process_remote_multi(self, **kwargs):
        """
        :param kwargs:
                mode: import, export
                ids: []
        :return:
        """
        kwargs.update(
            {
                'odoo_model': self,
                'ids': self.ids,
            }
        )
        if kwargs.get('mode') == 'import':
            logger.info(f'Import "{self}". Create jobs.')
            company = kwargs.get('instance').company_id

            for rec in self.with_context(company_id=company.id):
                rec._save_transaction_info('pending', '', company.id)

                # job_kwargs = rec._get_transaction_job_kwargs(map_type)
                # rec._mark_failed_jobs_as_cancel(identity_key=job_kwargs['identity_key'])
                #
                # rec.with_delay(**job_kwargs)._export_qbo_one(map_type, company)

                rec.with_delay(**rec._get_job_params())._process_remote_single(**kwargs)
            if not self:
                self.with_context(company_id=company.id).with_delay(**self._get_job_params())._process_remote_single(**kwargs)


    def _process_remote_single(self, **kwargs):
        if kwargs.get('mode') == 'import':
            kwargs.update(
                {
                    'ids': self.ids,
                    'integration_model_instance': self,
                }
            )
            instance = self.jira_integration_settings if self.jira_integration_settings else kwargs.get('instance')
            res = instance.api_call(**kwargs)
            return self.apply_changes(**res)

    def _map_vals_from_remote(self):
        ...

    def _map_vals_to_remote(self):
        ...

    def apply_changes(self, **kwargs):
        res = []
        if kwargs.get('mode') == 'import':
            if not kwargs.get('odoo_model'):
                # add or update if found existed
                ...
                map_model = getattr(self,'_odoo_map_list')
                orm_commands = map_model()(self, kwargs.get('http_response'))
                if not orm_commands:
                    return res
                if not self.ids:
                    for i, item in enumerate(orm_commands):
                        if item[0] == Command.CREATE:
                            vals_dict = item[2]
                            domain_match = []
                            if vals_dict.get('jira_id'):
                                domain_match.append(('jira_id', '=', vals_dict['jira_id']))
                            if vals_dict.get('jira_key'):
                                if domain_match:
                                    domain_match.insert(0, '|')
                                domain_match.append(('jira_key', '=', vals_dict['jira_key']))
                            domain_match.append(('active', '=', True))
                            existed_item = self.search(domain_match)
                            if existed_item:
                                if existed_item[0].allow_sync:
                                    orm_commands[i] = Command.update(existed_item[0].id, vals_dict)
                                else:
                                    orm_commands[i] = {}
                    orm_commands = [item for item in orm_commands if item]
                else:
                    orm_commands = [Command.update(self.ids[0], item[2]) for item in orm_commands if item]

                for item in orm_commands:
                    if item[0] == Command.CREATE:
                        res.append(self.create(item[2]))
                    elif item[0] == Command.UPDATE:
                        res.append(existed_item[0].write(item[2]))
                return res
            else:
                # update specified
                ...
                return res

    def import_data_from_jira(self, **kwargs):
        logger.info('Importing data from Jira')
        for instance in self.jira_integration_settings.search([]):
            self._process_remote_multi(mode='import', instance=instance, **kwargs)
