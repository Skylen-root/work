# Copyright 2025 Solvve.com Oleh Oshchypok
# Credentials and instance integration settings

import json
import logging
from collections import defaultdict

from odoo import models, api, fields, SUPERUSER_ID, _
from odoo.exceptions import ValidationError, UserError
from urllib3.util import parse_url, Url
import urllib.parse
import requests
import traceback
import pickle
import base64
from requests.auth import AuthBase, HTTPBasicAuth

logger = logging.getLogger(__name__)

class AuthJiraToken(HTTPBasicAuth):
    ...


class JiraIntegrationSettings(models.Model):
    _name = 'jira.integration.settings'
    _description = 'Jira Integration Settings for Instance'

    name = fields.Char(string='Instance Settings Name')
    instance_link = fields.Char(string='Instance Link')
    login = fields.Char(string='Login')
    api_token = fields.Char(string='API Token')
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.user.company_id)
    connection_state = fields.Selection([('draft', 'Draft'), ('done', 'Done') , ('failed', 'Failed')], default='draft')

    def drop_slash(self, vals_list):
        for i, vals in enumerate(vals_list):
            if vals.get('instance_link') and vals.get('instance_link')[-1] == '/':
                vals_list[i]['instance_link'] = vals_list[i]['instance_link'][:-1]

    @api.model_create_multi
    def create(self, vals_list):
        self.drop_slash(vals_list)
        return super().create(vals_list)

    def write(self, vals_list):
        self.drop_slash([vals_list])
        return super().write(vals_list)

    def connect(self, vals_list):
        if not self.instance_link or not self.api_token or not self.login:
            raise UserError(_("Error in connection Settings"))

    def http_call(self, **kwargs):

        # _http_request_url = Url(
        #     scheme=kwargs.get('http_scheme'),
        #     host=kwargs.get('host'),
        #     port=kwargs.get('port'),
        #     path='/'.join([p for p in [kwargs.get('base_path'), kwargs.get('path')] if p not in (None, False)])
        # )

        url = urllib.parse.urljoin(kwargs.get('base_url'), kwargs.get('base_path') + kwargs.get('api_endpoint'))

        _http_request_kwargs = {
            'method': kwargs.get('http_request_type'),
            'url': url,
            'headers': kwargs.get('headers') or {"Accept": "application/json"},
            'auth': AuthJiraToken(username=self.login, password=self.api_token),
            'params': kwargs.get('params'),
            'data': kwargs.get('request_params'),
            'json': kwargs.get('body'),
            'verify': True,
        }

        errors = []

        logger.debug(f"Http Request kwargs: {_http_request_kwargs}")
        try:
            with requests.api.request(**_http_request_kwargs) as r:
                _http_response = r
        except Exception as e:
            logger.error(f'\nJira Api Error\n Traceback: {traceback.format_exc()}.\n{e}')
            message = f'\n' \
                      f'{traceback.format_exc()}\n' \
                      f'\n' \
                      f'{str(e)}\n' \
                      f'\n' \
                      f'{"1"}'
            errors.append(message)
            kwargs.update({
                # 'http_response': _http_response.text,
                # 'http_status_code': _http_response.status_code,
                # 'http_response_headers': dict(_http_response.headers),
                'errors': errors
            })
            raise ConnectionError(e)
        if _http_response and _http_response.status_code not in (200, 201, 202, 409):
            try:
                response_json = _http_response.json()
                parsed_part = json.dumps(response_json, indent=2, ensure_ascii=False)
                message = (
                    f"\n--- Error Invalid Response Code. Status: {_http_response.status_code}\n"
                    f"\nHeaders:\n{_http_response.headers}\n"
                    f"\nParsed JSON response:\n{parsed_part}\n"
                )
            except json.JSONDecodeError:
                message = (
                    f"\n--- Error Invalid Response Code. Status: {_http_response.status_code}\n"
                    f"\nHeaders:\n{_http_response.headers}\n"
                    f"\nRaw text:\n{_http_response.text}\n"
                )
            errors.append(message)
            kwargs.update({
                'http_response': _http_response.text,
                'http_status_code': _http_response.status_code,
                'message': message,
                'errors': errors,
                'http_response_headers': dict(_http_response.headers),
            })

            raise Exception(_http_response.status_code, message, _http_response)

        if _http_response:
            kwargs.update({
                'http_response': _http_response.text,
                'http_status_code': _http_response.status_code,
                'http_response_headers': dict(_http_response.headers),
                'errors': errors,
                'state': 'ok',
            })
        logger.info(f"task completed! {kwargs}")
        return kwargs

    def api_call(self, mode='import', **kwargs):
        instance = kwargs.get('instance')
        if instance is None:
            raise ValueError('Integration Model Instance is required')
        odoo_model = kwargs.get('odoo_model')
        odoo_model_remote_key = None
        if kwargs.get('odoo_dependency_id'):
            odoo_model_remote_key = self.env[odoo_model._api_import_dependency].browse(kwargs.get('odoo_dependency_id')).jira_key
        params = kwargs.get('params')
        import_params = odoo_model._api_import_request_params
        export_params = odoo_model._api_export_request_params
        http_query_params = None
        start_at = kwargs.get('stat_at') or 0
        if mode == 'import' and import_params:
            http_query_params = import_params
        if mode == 'export' and export_params:
            http_query_params = export_params
        if http_query_params:
            params = {key: type(value) == str and value.format(REMOTE_KEY=odoo_model_remote_key, START_AT=start_at) or value for key, value in http_query_params.items() if value is not None}
        kwargs.update({
            'integration_model': instance,
            'mode': mode,
            'http_request_type': odoo_model._http_method_import if mode == 'import' else odoo_model._http_method_export,
            'base_url': self.instance_link,
            'base_path': 'rest',
            'api_endpoint': odoo_model._api_endpoint,
            'params': params,
        })
        return self.http_call(**kwargs)

    def connection_test(self):
        self.api_call('project.project', 'import')
