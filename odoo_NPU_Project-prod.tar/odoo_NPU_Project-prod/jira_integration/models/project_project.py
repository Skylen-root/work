# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import models
from .jira_integration_mixin import OdooMapModel, RelatedModel, JsonPathObject, OdooMapRecord
from typing import Any, Dict, Type, Optional, get_origin, get_args, List, Union
from pydantic import BaseModel, Field, GetCoreSchemaHandler


class OdooMapProject(OdooMapModel):
    _model_name: str = 'project.project'
    uid: int = Field(default=None,
        json_schema_extra={
            '_model_name': 'res.users',
            'json_path': '$.user',
            'domain': [],
            'normalize': lambda x: x,
            'reverse': lambda x: x,
            'const': None,
        }
    )
    name: str|None = Field(default=None, alias='$.name')
    jira_id: str|None = Field(default=None, alias='$.id')
    jira_key: str|None = Field(default=None, alias='$.key')
    jira_type: str|None = Field(default=None, alias='$.projectTypeKey')


class OdooMapProjectList(OdooMapModel):
    _model_name: str = 'project.project'
    records: List[OdooMapProject] = Field(
        default_factory=list,
        json_schema_extra={'json_path': '$[]'},
    )


class Project(models.Model):
    _name = 'project.project'
    _description = "Project"
    _inherit = ['project.project', 'jira.integration.mixin']

    _http_method_read = 'GET'
    _http_method_update = 'POST'
    _api_endpoint = '/api/3/project'

    _odoo_map_list = OdooMapProjectList
    _odoo_map_record = OdooMapProject

    def import_data_from_jira(self, **kwargs):
        super().import_data_from_jira(**kwargs)

    def apply_changes(self, **kwargs):
        return super().apply_changes(**kwargs)
